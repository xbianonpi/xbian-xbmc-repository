skin.amber
==========

Amber skin for XBMC